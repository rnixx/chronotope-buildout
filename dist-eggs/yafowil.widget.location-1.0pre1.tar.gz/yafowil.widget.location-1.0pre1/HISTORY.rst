History
=======

1.0 (unreleased)
----------------

- Make it work.
  [rnix]
