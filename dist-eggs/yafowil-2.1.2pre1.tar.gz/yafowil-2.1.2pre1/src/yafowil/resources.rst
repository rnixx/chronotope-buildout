Required imports::

    >>> from yafowil.resources import YafowilResources

Check base resources::

    >>> resources = YafowilResources()
    >>> resources.js_resources
    [...]

    >>> resources.css_resources
    [...]
