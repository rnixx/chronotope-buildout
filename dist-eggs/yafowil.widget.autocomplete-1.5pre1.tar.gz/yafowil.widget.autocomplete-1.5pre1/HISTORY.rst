
History
=======

1.5 (unreleased)
----------------

- Update jquery UI autocomplete to 1.10.3 and use latest jquery ui boostrap
  styles.
  [rnix, 2014-07-05]

1.4.1
-----

- use ``yafowil.utils.attr_value`` wherever possible.
  [rnix, 2012-10-25]

1.4
---

- Add ``generic_required_extractor`` to extraction chain
  [rnix, 2012-07-25]

- Adopt resource providing
  [rnix, 2012-06-12]

- Remove example app
  [rnix, 2012-06-12]

1.3
---

- Support JavaScript callback functions in source attribute
  [rnix, 2011-10-03]

- register autocomplete binder in ``yafowil.widget.array`` hooks if installed
  [rnix, 2011-10-03]

- register plan and depend on yafowil 1.3
  [jensens, 2011-09-30]

1.2
---

- adopt to yafowil 1.2
  [jensens, 2011-09-20]

- resource available in plain Zope2
  [jensens, 2011-09-20]

1.1
---

- adopt to yafowil 1.1
  [rnix, 2011-07-08]

1.0.1
-----

- test coverage
  [rnix, 2011-05-07]

1.0
---

- made it work
  [jensens, 2010-11-24]
