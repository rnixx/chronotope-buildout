This is an **image widget** for for `YAFOWIL
<http://pypi.python.org/pypi/yafowil>`_ .

- `Documentation <http://docs.yafowil.info/en/latest/blueprints.html#image>`_
- `DEMO - see it Live <http://demo.yafowil.info/++widget++yafowil.widget.image/index.html>`_


Source Code
===========

The sources are in a GIT DVCS with its main branches at
`github <http://github.com/bluedynamics/yafowil.widget.image>`_.

We'd be happy to see many forks and pull-requests to make YAFOWIL even better.


Contributors
============

- Robert Niederreiter <rnix [at] squarewave [dot] at>
