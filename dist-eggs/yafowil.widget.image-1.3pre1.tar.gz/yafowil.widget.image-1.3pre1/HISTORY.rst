
History
=======

1.3 (unreleased)
----------------

- Add top margin to input.
  [rnix, 2014-08-06]

- Check for already existing query parameters befor adding nocache param to
  img src.
  [rnix, 2014-07-11]


1.2
---

- Add translations, package depends now ``yafowil`` >= 2.1
  [rnix, 2014-04-30]


1.1.2
-----

- CSS fix.
  [rnix, 2012-10-30]


1.1.1
-----

- use ``yafowil.utils.attr_value`` wherever possible.
  [rnix, 2012-10-25]


1.1
---

- Adopt resource providing
  [rnix, 2012-06-12]

- Provide example widget
  [rnix, 2012-06-12]


1.0.1
-----

- Add ``nocache`` request parameter to image ``src`` on edit.
  [rnix, 2012-31-05]

- JS Fix.
  [rnix, 2012-31-05]


1.0
---

- Make it work
  [rnix]
