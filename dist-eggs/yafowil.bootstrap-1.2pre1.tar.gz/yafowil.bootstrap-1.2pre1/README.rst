This is the **bootstrap styles integration** for for `YAFOWIL 
<http://pypi.python.org/pypi/yafowil>`_ - Yet Another Form Widget Library.


Detailed Documentation
======================

If you're interested to dig deeper: The
`detailed YAFOWIL documentation <http://docs.yafowil.info>`_ is available.
Read it and learn how to create your example application with YAFOWIL forms
in 15 minutes.


Source Code
===========

The sources are in a GIT DVCS with its main branches at
`github <http://github.com/bluedynamics/yafowil.bootstrap>`_.

We'd be happy to see many forks and pull-requests to make YAFOWIL even better.


Contributors
============

- Robert Niederrreiter <rnix [at] squarewave [dot] at>

- Jens Klein <jens [at] bluedynamics [dot] com>

- Johannes Raggam <johannes [at] raggam [dot] co [dot] at>

- Peter Holzer <peter.holzer [at] agitator [dot] com>
