
History
=======

1.2 (unreleased)
----------------

- Use ``configure`` entry point for theme configuration.
  [rnix]

- Rename resource group ``bootstrap`` to ``bootstrap.dependencies``.
  [rnix]

- Remove bootstrap macros for yafowil and set factory defaults for common
  widgets where appropriate.
  [rnix]

- Update to bootstrap 3.2.
  [rnix]

1.1
---

- Register the bootstrap.js javascript too.
  [thet]

1.0
---

- make it work
  [rnix, jensens, thet, et al.]
