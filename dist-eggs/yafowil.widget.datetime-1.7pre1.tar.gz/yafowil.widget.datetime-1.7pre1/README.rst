This is a **datetime widget** for for `YAFOWIL 
<http://pypi.python.org/pypi/yafowil>`_ 

It utilizes/integrates `jquery.ui.datepicker 
<http://docs.jquery.com/UI/Datepicker>`_ for/in YAFOWIL providing a 
datepicker function on a text input.

- `Documentation <http://docs.yafowil.info/en/latest/blueprints.html#datetime>`_
- `DEMO - see it Live <http://demo.yafowil.info/++widget++yafowil.widget.datetime/index.html>`_


Contributors
============

- Robert Niederrreiter <rnix [at] squarewave [dot] at>
