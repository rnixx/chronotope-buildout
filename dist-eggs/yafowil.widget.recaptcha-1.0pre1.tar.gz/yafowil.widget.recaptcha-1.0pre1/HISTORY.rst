History
=======

1.0 (Unreleased)
----------------

- Make it work.
  [rnix]
