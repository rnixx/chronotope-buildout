History
=======

1.1 (Unreleased)
----------------

- ``select2`` provides key/term vocabularies for preselected items.
  [rnix, 2014-07-10]

- Remove ``select2input`` blueprint, use ``inputtag`` property of ``select2``
  blueprint instead.
  [rnix, 2014-06-19]

- Provide all available constructor options in blueprint.
  [rnix, 2014-06-19]

- Update select widget to 3.5.0.
  [rnix, 2014-06-19]

1.0
---

- Make it work.
  [thet]
